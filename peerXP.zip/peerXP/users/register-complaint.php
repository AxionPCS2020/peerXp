<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
if(isset($_POST['submit']))
{

$uid=$_SESSION['id'];
$department=$_POST['department'];
$category=$_POST['category'];
$subcat=$_POST['subject'];
$complaintype=$_POST['mobile'];
$priority=$_POST['priority'];
$complaintdetials=$_POST['complaindetails'];
$mail =$_POST['userEmail'];

$query= "INSERT into `tblcomplaints`(userId,department,category,subject,mobile,description,priority,status) values('$uid','$department','$category','$subcat','$complaintype','$complaintdetials','$priority','open')";
$db = mysqli_query($con,$query);

 $postfield = [                
                  'subCategory'=> 'Sub General',
                  'cf'=>[ 
                    'cf_permanentaddress'=> null,
                    'cf_dateofpurchase'=> null,
                    'cf_phone'=> $complaintype,
                    'cf_numberofitems'=> null,
                    'cf_url'=> $uid,
                    'cf_secondaryemail'=> null,
                    'cf_severitypercentage'=> '0.0',
                    'cf_modelname'=> 'F3 2017'
                  ],
                  'productId'=> '',
                  'contactId'=> '7189000000975002',
                  'subject'=> $subcat,
                  'dueDate'=> "2016-06-21T16:16:16.000Z",
                  'departmentId'=> '7189000000051431',
                  'channel'=> 'Email',
                  'description'=> $complaintdetials,
                  'priority'=> $priority,
                  'classification'=> '',
                  'assigneeId'=> '7189000000780054',
                  'phone'=> $contactNo,
                  'category'=> 'general',
                  'email'=> $mail,
                  'status'=> 'Open'
                     ];

             $arr = json_encode($postfield);
               
             $ch1 = curl_init();
        
          curl_setopt($ch1, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch1, CURLOPT_URL,'https://desk.zoho.in/api/v1/tickets?orgId=60001280952');
          curl_setopt($ch1, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
          curl_setopt($ch1, CURLOPT_POST, true);
          curl_setopt($ch1, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch1, CURLOPT_POSTFIELDS, $arr);
          curl_setopt($ch1, CURLOPT_HTTPHEADER, array(
                    'Content-Type: application/json',
                    'Accept: application/json',
                    "Authorization:aa8cd2f4d25aa3418e47f953ad9fe323",
                    'Content-Length: ' . strlen($arr)  
                   ));
                $response1 = curl_exec($ch1);
                curl_close($ch1);
                $json1 = json_encode($response1);
                $books1 = json_decode($json1, true);
                $res1 = json_decode($books1);  
               
               if($res1->statusType != ''){
                
               echo '<script> alert("Your complain has been successfully filled"); </script>';
              }else{
                echo '<script> alert("Request Failed"); </script>'; 
              }
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>User Register Ticket</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-datepicker/css/datepicker.css" />
    <link rel="stylesheet" type="text/css" href="assets/js/bootstrap-daterangepicker/daterangepicker.css" />
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
   
  </head>

  <body>

  <section id="container" >
     <?php include("includes/header.php");?>
      <?php include("includes/sidebar.php");?>
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Register New Ticket</h3>
          	
          	<!-- BASIC FORM ELELEMNTS -->
          	<div class="row mt">
          		<div class="col-lg-12">
                  <div class="form-panel">
                  	

                      <?php if($successmsg)
                      {?>
                      <div class="alert alert-success alert-dismissable">
                       <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <b>Well done!</b> <?php echo htmlentities($successmsg);?></div>
                      <?php }?>

   <?php if($errormsg)
                      {?>
                      <div class="alert alert-danger alert-dismissable">
 <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                      <b>Oh snap!</b> </b> <?php echo htmlentities($errormsg);?></div>
                      <?php }?>

                      <form class="form-horizontal style-form" method="post" name="complaint" enctype="multipart/form-data" >

<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Department</label>
<div class="col-sm-4">
  <select class="form-control" name="department">
                        <option value="0">- Select -</option>
                        <option value="PWSLab-DevOps-Support">PWSLab DevOps Support</option>
                        <option value="iSupport">iSupport</option>
                        <option value="Naveena">Naveena</option>
                        <option value="omjit">omjit</option>
                      </select>
 </div>
<label class="col-sm-2 col-sm-2 control-label">Category </label>
 <div class="col-sm-4">
<select class="form-control" name="category">
                        <option value="0">- Select -</option>
                        <option value="New-project-CI/CD-Pipeline-setup">New project CI/CD Pipeline setup</option>
                        <option value="Update-CI/CD-Pipeline-configuration">Update CI/CD Pipeline configuration</option>
                        <option value="DevSecOps-Pipeline-setup">DevSecOps Pipeline setup</option>
                            <option value="CI/CD-Pipeline-failure">CI/CD Pipeline failure</option>
                            <option value="Automated-Deployment-failure">Automated Deployment failure</option>
                            <option value="Docker-and-containers">Docker and containers</option>
                            <option value="User-management-and-project-access">User management and project access</option>
                            <option value="Git-source-control">Git source control</option>
                            <option value="Others">Others</option>
            
                      </select></div>
 </div>

<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Subject</label>
<div class="col-sm-4">
<input type="text" name="subject" required="required" value="" required="" class="form-control">
</div>
<?php
 $q=mysqli_query($con,"SELECT userEmail,fullName FROM users WHERE id='".$_SESSION['id']."'");
    
    while($row=mysqli_fetch_array($q))//while look to fetch the result and store in a array $row.  
        {  
            $user_id=$row[0];
            $user_name=$row[1];
            
 ?>
 <label class="col-sm-2 col-sm-2 control-label">User Name</label>
<div class="col-sm-4">
<input type="text" name="userName" value="<?php echo $user_name; ?>" required="" class="form-control" readonly/>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Mobile</label>
<div class="col-sm-4">
<input type="text" name="mobile" required="required" value="" required="" class="form-control">
</div>

<label class="col-sm-2 col-sm-2 control-label">User Email</label>
<div class="col-sm-4">
<input type="email" name="userEmail" value="<?php echo $user_id; ?>" class="form-control" readonly/>
</div>
<?php } ?>
</div>


<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Priority</label>
<div class="col-sm-4">
<select class="form-control" name="priority">
                            <option value="none">-None-</option>
                            <option value="high">High</option>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                        </select></div>

</div>


<div class="form-group">
<label class="col-sm-2 col-sm-2 control-label">Description </label>
<div class="col-sm-6">
<textarea  name="complaindetails" required="required" cols="10" rows="10" class="form-control" maxlength="2000"></textarea>
</div>
</div>



                          <div class="form-group">
                           <div class="col-sm-10" style="padding-left:25% ">
<button type="submit" name="submit" class="btn btn-primary">Submit</button>
</div>
</div>

                          </form>
                          </div>
                          </div>
                          </div>
                          
          	
          	
		</section>
      </section>
    
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>

	<!--custom switch-->
	<script src="assets/js/bootstrap-switch.js"></script>
	
	<!--custom tagsinput-->
	<script src="assets/js/jquery.tagsinput.js"></script>
	
	<!--custom checkbox & radio-->
	
	<script type="text/javascript" src="assets/js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap-daterangepicker/date.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap-daterangepicker/daterangepicker.js"></script>
	
	<script type="text/javascript" src="assets/js/bootstrap-inputmask/bootstrap-inputmask.min.js"></script>
	
	
	<script src="assets/js/form-component.js"></script>    
    
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>


<?php } ?>
